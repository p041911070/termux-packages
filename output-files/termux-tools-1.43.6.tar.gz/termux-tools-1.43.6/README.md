# termux-tools

Some scripts and small programs that are packaged into termux's
termux-tools package.
